Run AVL Tree.exe for the main program
code is found in \source