#include "AVLProgram.h"

int main()
{
	auto* program = new AVLProgram();

	program->Run();

	return 0;

}